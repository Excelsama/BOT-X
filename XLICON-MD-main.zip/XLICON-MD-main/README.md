
</p>
<p align="center">
  <a href="https://chat.whatsapp.com/ESB8e9HAS2wGlwBvzGYnLx">
    <img alt=Support height="250" src="https://telegra.ph/file/3c341828d86ee7a89c73f.jpg"> 
    </p>
      <div align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Impact&size=50&pause=1000&color=000000&center=true&width=910&height=100&lines=THIS IS+XLICON-MD ;MULTI+DEVICE+WHATSAPP+BOT;CREATED+BY+THE TEAM XLICON ;PUBLIC+RELESED+DATE;2023/08/11; THIS +BOT IS+BASED+FROM; OF SECKTOR-MD;SO FULL+SCRIPT+CREDIT+GOES+TO;TEAM SECKTOR." alt="Typing SVG" /></a>
  </p>
  <br>

</p>
  
  # ```Tap Here For Help``` 
  
  <p align="left">
  <a href="https://wa.me/8801853262586?text=Hello%20Slasher~Kun%20sir...%20I%20need%20some%20help%20in%20Xlicon%20md">
    <img align="left" alt="SIEGRIN | Whastapp" width="26px" src="https://raw.githubusercontent.com/PikaBotz/My_Personal_Space/main/Images/AnyaBot_pics/Anya_v2/Whatsapp.svg" />
  Tap here for contact me on WhatsApp Messenger 
  </p>
  <p align="center">
  <a href="My email: infiniteytff@gmail.com">
    <img align="left" alt="SIEGRIN | Gmail" width="26px" src="https://raw.githubusercontent.com/PikaBotz/My_Personal_Space/main/Images/AnyaBot_pics/Anya_v2/Gmail.svg" />
  
    My email Adress : infiniteytff@gmail.com
     
 </p>
  <a href="https://github.com/salmanytofficial/XLICON-MD/fork" target="blank"><img align="center" src="https://i.imgur.com/cxaSEWe.png" alt="Deploy bot" height="80" width="200" /></a>
  <div>
<br>
</p>

# ```Scan QR Here```
<a href="https://replit.com/@ahil15/XLICON-MD-QR-V4?v=1"><img src="https://i.ibb.co/Lvpp8Hw/images.jpg" align="center" width="90" /> </a>
<div align="center">
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Impact&weight=200&size=15&pause=1000&color=F70000&width=300&height=100&lines=CLICK+THE+SCANNER+LOGO+TO+SCAN" alt="Typing SVG" /></a>
   
# ```EXTERNAL STUFF AND API```

●.*Install* [External Plugins](https://github.com/SamPandey001/Secktor-Plugins)

●.  ***Get a Mongodb uri from [Clever-Cloud](https://api.clever-cloud.com/v2/session/login).***

●.  ***Get a Mongodb uri from [railway.app](https://railway.app).***

# ```PUBLIC MONGODB URI```
```
mongodb+srv://ahil1:787191784abhi@ahil1.kzr1tt3.mongodb.net/?retrywrites=true&w=majority
```

 # Deploy METHOD
 
 <details close>
<summary>Click to choose your favourite platform to Deploy</summary>
 
<br><br>   
   
<h4 align="center"> Deploy on Repl.it
</h4>

<p align="center" >
    <a href="https://repl.it/github/salmanytofficial/XLICON-MD">
    <img src="https://i.ibb.co/zrB5kMh/deploy-on-repl.jpg" width="170px" alt="Deploy on Heroku" >
    </a>
</p>

<p align="center" >
    <br>
    __________________________
    <br>
</p>

<br>
      
<h4 align="center"> Deploy on Koyeb
</h4>
      
<p align="center">
    <a href="https://app.koyeb.com/apps/deploy?type=git&repository=github.com/salmanytofficial/XLICON-MD&branch=main&env[SESSION_ID]&env[OWNER_NUMBER]=8801853262586&env[MONGODB_URI]&&env[OWNER_NAME]=SLASHER&env[KOYEB_API]&env[PREFIX]=.&env[ALIVE_IMG]=https://telegra.ph/file/1da92586c209009d5131d.jpg&env[global_url]=instagram.com&env[FAKE_COUNTRY_CODE]=92&env[READ_MESSAGE]=false&env[DISABLE_PM]=false&env[WORKTYPE]=public&env[THEME]=GOJO&env[PACK_INFO]=XLICON-MD;BY-SALMANYTOFFICIAL&name=XLICON-MD&env[KOYEB_NAME]=XLICON-MD&env[ANTILINK_VALUES]=chat.whatsapp.com&env[PORT]=8000)">
    <img src="https://www.koyeb.com/static/images/deploy/button.svg" alt="Deploy on Koyeb" width="155px">
    </a>
   
</p>


<p align="center" >
    <br>
    __________________________
    <br>
</p>


<br>
 
<h4 align="center"> Deploy on Heroku
</h4>

</p>

<p align="center" >
    <a href="https://heroku.com/deploy?template=https://github.com/salmanytofficial/XLICON-MD">
    <img src="https://www.herokucdn.com/deploy/button.png" width="160px" alt="Deploy on Heroku" >
    </a>

</p>

<p align="center" >
    <br>
    __________________________
    <br>
</p>


<br>


<h4 align="center"> Deploy on Mogenius
</h4>
  
<p align="center">
    <a href="https://studio.mogenius.com/">
    <img src="https://www.cloudflare.com/static/90073b1e5bd8a0765640a20febb3dc22/mogenius_logo_quer.png" alt="Deploy on Mogenius" width="170px">
    </a>
    
</p>

<p align="center" >
    <br>
    __________________________
    <br>
</p>

<br>

<h4 align="center"> Deploy on Uffizzi
</h4>
  
<p align="center">
    <a href="https://www.uffizzi.com/">
    <img src="https://i.ibb.co/Y29Kv4X/Screenshot-195.png" alt="Deploy on Uffizzi" width="125px">
    </a>
    
</p>

<br>

<h4 align="center"> Deploy on BoxMineWorld
</h4>
  
<p align="center">
    <a href="https://dash.boxmineworld.com/">
    <img src="https://graph.org/file/2af0e67f320986702ea24.jpg" alt="Deploy on Boxmineworld" width="175px">
    </a>
    <br>

</p>

<p align="center" >
    <br>
    __________________________
    <br>
</p>



</details>

<br>

 # XLICON MD SUPPORT
 
 <details close>
<summary> JOIN OUR WHATSAPP GROUP AND SUPPORT OUR YOUTUBE CHANNEL</summary>
 
<br><br>   

<p align="center"> 
 
  <a aria-label="Join our chats" href="https://chat.whatsapp.com/ESB8e9HAS2wGlwBvzGYnLx" target="_blank">
   
<img alt="whatsapp" src="https://img.shields.io/badge/Join Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

  </a>
  
***<p align="center"> Support us by subscribing our channel </p>***
 
   <p align="left">  
  <a href="https://youtube.com/@s4salmanyt">
    <img alt="Xlicon docs" height="100" src="https://t3.ftcdn.net/jpg/03/00/38/90/360_F_300389025_b5hgHpjDprTySl8loTqJRMipySb1rO0I.jpg">
    <h1 align="left">Tap on above Image</h1>
  </a>
</p>

<p align="center" >
    <br>
    __________________________
    <br>
</p>



</details>

<br>




If ***RUN*** Doesn't work, paste these commands in repl shell

```
yarn
npm i pm2 -g && pm2 start lib/client.js
```
Copy the JSON down and paste in repl then fill the vars

```
{
  "SESSION_ID": "ID-Here",
  "OWNER_NUMBER": "92xxxxxxxxxx",
  "OWNER_NAME": "GOJO SATURO",
  "OPENAI_API_KEY": "Paste OpenAI Api Key here",
  "MONGODB_URI": "mongodb+srv://ahil1:787191784abhi@ahil1.kzr1tt3.mongodb.net/?retrywrites=true&w=majority",
  "PACK_AUTHER": "Xlicon",
  "PACK_NAME": "Wa-BOT",
  "PREFIX": "."
   
}
```

<br><br>

# Warning:
    
- This bot is not made by WhatsApp.inc so overusing this bot may result in WhatsApp account ban.
- We will only assist you in `Bot Deployment ( Installation or Hosting )`. Not in `Bot Development`.
- If you Modify this bot and face any issues, I am not responsible for that because it's not possible for me or my team to help everyone in bot Development / Modification. Only modify if you know what you are doing.
- This bot is made for `Educational / Fun / Group Management` purposes only. I and the team will not be responsible for any misuse of this bot.
- We will only assist you in `Setup / Deployment` of this bot.

<br><br>

# Legal Disclaimer

- We suggest you to use your `Own MongoDB URL` while deploying inside `.env` or `Environment Variables`. That will increase your Privacy and Security.
- We don't recommend to hardly modify the script. `If you do so, you will be responsible for any issues / bugs and we will not provide any support` as we are also busy in our life.
- We will not be responsible for any issues caused by any individual hosting this bot and cause any harm to any Group `(So don't make someone Group Admin who you don't know just because they are hosting the Bot)`.

<br><br>

---
<br>

<h2 align="center">TEAM-XLICON
</h2>

 [![SalmanYtOfficial](https://github.com/salmanytofficial.png?size=100)](https://github.com/salmanytofficial)  [![ProfileCorruptedError](https://github.com/ahil15.png?size=100)](https://github.com/ahil15)  [![KALINDU-LK](https://github.com/KALINDU-LK.png?size=100)](https://github.com/KALINDU-LK)  [![SUHAIL TECH ](https://github.com/suhailtechinfo.png?size=100)](https://github.com/suhailtechinfo) 
 
 [SalmanYtOfficial](https://github.com/salmanytoffcial) | [ProfileCorruptedError](https://github.com/ahil15) | [SUHAIL TECH](https://github.com/suhailtechinfo) | [KALINDU-LK](https://github.com/KALINDU-LK)
 
 
  </div>

#### ```TOTAL REPO VIEWS```

![Visitor Count](https://profile-counter.glitch.me/XLICON-MD/count.svg)

SUPPORT GROUP: <a href="https://chat.whatsapp.com/ESB8e9HAS2wGlwBvzGYnLx"><img alt="WhatsApp" src="https://camo.githubusercontent.com/2157131829ac512183ee8f8b6c6f803688a4cc66a2e686602844e80478401a7c/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f4a6f696e2047726f75702d3235443336363f7374796c653d666f722d7468652d6261646765266c6f676f3d7768617473617070266c6f676f436f6c6f723d7768697465"/></a>

- Star the repo IF u like XLICON

## License

The Xlicon made available under the [GPL-3 license](https://github.com/salmanytofficial/XLICON-MD/blob/main/LICENCE). 
