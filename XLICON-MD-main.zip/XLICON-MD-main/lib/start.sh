while true
do
echo "Starting Xlicon-Md..."
node lib/client.js
done
